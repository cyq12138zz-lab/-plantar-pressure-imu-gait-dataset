# Dataset description

This local release candidate contains nine normal-gait recording groups (36448 cleaned bilateral samples) and four abnormal gait categories (in-toeing, out-toeing, waddling, and foot inversion), with four historical recording groups per category (30907 cleaned samples). There are 31 available source exports: 23 normal and 8 abnormal.

Identifiers represent recording groups, not verified independent participants. Normal pairs N04/N05, N06/N07 and N08/N09 share original recordings. Some abnormal group boundaries were assigned by equal-duration splitting without independent verification. Matching suffixes across categories do not establish participant identity. Clinical diagnosis or the simulated/clinical nature of each abnormal category has not been verified.

Nominal sampling rate: 25 Hz. Each sample contains bilateral pressure and IMU measurements. CSV files use UTF-8 with BOM. Numerical cell strings are preserved from existing source artifacts; this release performs no new filtering, augmentation, normalization, or label generation. Source exports have heterogeneous processing states, including already processed normal recordings, and must not all be described as raw hardware streams.

Phase codes are -1 excluded, 0 SW, 1 HS, 2 FF and 3 HO. These are pressure-rule reference labels, not independent video, force-plate, manual, or clinical ground truth. HS/FF/HO denote rule-defined early/middle/late stance stages.

Do not split adjacent samples or overlapping windows randomly. Keep shared source recordings together, and verify participant independence separately. Restrict windows to one file, source, foot and continuous segment, with continuous original row indices and nominal time intervals. Historical split columns are retained for provenance, not endorsed as an independent-subject benchmark.

Measurement units and calibration remain inherited and require confirmation by the data collector. According to the data provider on 2026-11-03, all participants are students at the University of Jinan and agreed to public data release. Written consent documentation and ethics records have not been supplied with this package. No public upload has been performed.
