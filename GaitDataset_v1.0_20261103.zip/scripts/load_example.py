from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parents[1]
index = ROOT / "metadata/recording_groups.csv"
with index.open(encoding="utf-8-sig", newline="") as f:
    groups = list(csv.DictReader(f))
for g in groups:
    print(g["recording_group_id"], g["gait_type"], g["rows"], g["path"])
sample = ROOT / groups[0]["path"]
with sample.open(encoding="utf-8-sig", newline="") as f:
    row = next(csv.DictReader(f))
channels = [f"left_p{i}_zero_filt" for i in range(1, 9)] + ["left_total_pressure"] + [f"left_{kind}_{axis}_zero_filt" for kind in ("acc", "gyro") for axis in "xyz"]
print("First left-foot sample:", [float(row[c]) for c in channels])
print("Reference phase:", row["left_phase_code"], "(pressure-rule reference only)")
