from pathlib import Path
import csv, json, hashlib, sys

ROOT = Path(__file__).resolve().parents[1]
def main():
    manifest = json.loads((ROOT / "checksums.json").read_text(encoding="utf-8"))
    errors = []
    for rel, expected in manifest.items():
        p = ROOT / rel
        if not p.is_file(): errors.append("missing: " + rel); continue
        actual = hashlib.sha256(p.read_bytes()).hexdigest()
        if actual != expected: errors.append("hash mismatch: " + rel)
    actual_files={p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
    if actual_files != set(manifest) | {"checksums.json"}: errors.append("unexpected or missing files")
    with (ROOT / "metadata/file_inventory.csv").open(encoding="utf-8-sig", newline="") as f:
        files=list(csv.DictReader(f))
    for x in files:
        with (ROOT/x["path"]).open(encoding="utf-8-sig", newline="") as f:
            r=csv.DictReader(f); cols=r.fieldnames; n=sum(1 for _ in r)
        if n!=int(x["rows"]) or len(cols)!=int(x["columns"]):errors.append("shape mismatch: "+x["path"])
    with (ROOT / "metadata/recording_groups.csv").open(encoding="utf-8-sig",newline="") as f: groups=list(csv.DictReader(f))
    if len(groups)!=25 or sum(g["gait_type"]=="normal" for g in groups)!=9:errors.append("recording-group mismatch")
    print(json.dumps({"status":"PASS" if not errors else "FAIL","hashes_checked":len(manifest),"data_files_checked":len(files),"recording_groups":len(groups),"errors":errors},ensure_ascii=False,indent=2))
    return 1 if errors else 0
if __name__ == "__main__":sys.exit(main())
